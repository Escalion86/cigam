<?php
error_reporting(0);
session_start();
$myuser = "dch";
$mypass = "dch";
if (isset($_POST['btndch'])) {
$user_get = $_POST['user'];
$psd_get = $_POST['pass'];
if ($user_get == $myuser && $psd_get == $mypass) {
    header ("Location: ./rezulta.php");
    $_SESSION['dchlog'] = $user.$psd;
    exit;}}
?>
<html>
<head>
<title>Rzulta DCH Amazone</title>
<link rel="stylesheet" type="text/css" href="admin.css">
<meta charset="utf-8">
</style>
</head>
<body><center>
<div id="bg"></div>
<form  method="POST">
  <label for=""></label>
  <input type="text" name="user" id="user" placeholder="Username" class="email">
  <label for=""></label>
  <input type="password" name="pass" id="pass" placeholder="password" class="pass">
  <button type="submit" name="btndch">login to your REZULTA</button>
</form>
</center></body>
</html>

